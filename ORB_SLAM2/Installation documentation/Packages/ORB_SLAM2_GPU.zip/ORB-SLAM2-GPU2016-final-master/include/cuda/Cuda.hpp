#pragma once
#ifndef __ORB_SLAM2_CUDA_HPP__
#define __ORB_SLAM2_CUDA_HPP__

namespace ORB_SLAM2 { namespace cuda {
  void deviceSynchronize();
} }

#endif
