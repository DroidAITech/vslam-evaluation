These files are here just for comparing and testing.
